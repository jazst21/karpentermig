# Simple Karpenter Migration Tool
Migrate your EKS cluster from NodeGroup Cluster Autoscaler to Karpenter

# Download
karpentermig is available on PyPI https://pypi.org/project/karpentermig/

```bash
pip install karpentermig
```