#Download
karpentermig is available on PyPI https://pypi.org/project/karpentermig/

```bash
pip install karpentermig
```